// Blockly.Blocks['tone'] = {
//     init: function () {
//         this.appendDummyInput("NAME")
//             .appendField("Tone")
//             .appendField(new Blockly.FieldDropdown([["A3", "sounds/piano/A3.mp3"], ["A4", "sounds/piano/A4.mp3"],["B3", "sounds/piano/B3.mp3"],["B4", "sounds/piano/B4.mp3"],["C3", "sounds/piano/C3.mp3"],["C4", "sounds/piano/C4.mp3"],["D3", "sounds/piano/D3.mp3"],["D4", "sounds/piano/D4.mp3"],["E3", "sounds/piano/E3.mp3"], ["E4", "sounds/piano/E4.mp3"],["F3", "sounds/piano/F3.mp3"], ["F4", "sounds/piano/F4.mp3"],["G3", "sounds/piano/G3.mp3"], ["G4", "sounds/piano/G4.mp3"],]), "Options");
//         this.setInputsInline(true);
//         this.setPreviousStatement(true, null);
//         this.setNextStatement(true, null);
//         this.setColour(130);
//         this.setTooltip("");
//         this.setHelpUrl("");
//     }
// };

/**
 * @license
 * Copyright 2012 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @fileoverview Blocks for Music game.
 * @author fraser@google.com (Neil Fraser)
 */

goog.require('CustomFields.FieldPitch');

Blockly.Blocks['tone'] = {
    /**
     * Block for playing note.
     * @this {Blockly.Block}
     */
    init: function() {
      var options = [
        [{"src": "sounds/note1.png",
          "width": 9, "height": 19, "alt": "whole"}, "1"],
        [{"src": "sounds/note0.5.png",
          "width": 9, "height": 19, "alt": "half"}, "0.5"],
        [{"src": "sounds/note0.25.png",
          "width": 9, "height": 19, "alt": "quarter"}, "0.25"],
        [{"src": "sounds/note0.125.png",
          "width": 9, "height": 19, "alt": "eighth"}, "0.125"],
        [{"src": "sounds/note0.0625.png",
          "width": 9, "height": 19, "alt": "sixteenth"}, "0.0625"]
      ];
      // Trim off whole and sixteenth notes for levels 1-9.
      this.jsonInit({
        "message0": "%1 %2",
        "args0": [
          {
            "type": "field_dropdown",
            "name": "DURATION",
            "options": options
          },
          {
            "type": "input_value",
            "name": "PITCH",
            "check": "Number"
          }
        ],
        "inputsInline": true,
        "previousStatement": null,
        "nextStatement": null,
        "colour": 180,
        "tooltip": ""
      });
    }
  };

Blockly.JavaScript['tone'] = function (block) {
    var dropdown_opt = block.getFieldValue('Options');

    // console.log(dropdown_opt);

    // var tone = new Howl({
    //     src: dropdown_opt,
    //     html5: true,
    //     volume: 0.5,
    // })

    // tone.play();

    var code = '';

    return code;
};



Blockly.JavaScript['test'] = function (block) {
    var statements_name = Blockly.JavaScript.statementToCode(block, 'NAME');
    // TODO: Assemble JavaScript into code variable.
    var code;

    code = '';

    if (jumpObject[this.id] == undefined) {
        localStorage[this.id] = 1;
        jumpObject[this.id] = new Howl({
            src: 'https://rpg.hamsterrepublic.com/wiki-images/2/21/Collision8-Bit.ogg',
            html5: true,
            loop: true,
            volume: 0.5,
        })
        jumpObject[this.id].play();
    }

    return code;
};